from http.server import BaseHTTPRequestHandler
import os
import json
import requests

BOT_TOKEN = os.environ.get("DISCORD_BOT_TOKEN")
REDIS_URL = os.environ.get("UPSTASH_REDIS_REST_URL")
REDIS_TOKEN = os.environ.get("UPSTASH_REDIS_REST_TOKEN")
BOT_API_SECRET = os.environ.get("BOT_API_SECRET")


def redis_cmd(*args):
    """Upstash Redis REST command"""
    r = requests.post(
        REDIS_URL,
        headers={"Authorization": f"Bearer {REDIS_TOKEN}"},
        json=list(args),
    )
    return r.json().get("result")


class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        # Проверка секрета
        auth = self.headers.get("X-Bot-Secret", "")
        if auth != BOT_API_SECRET:
            return self.json_response({"error": "Unauthorized"}, 401)

        # Читаем тело запроса
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length) or b"{}")
        guild_id = body.get("guild_id")

        if not guild_id:
            return self.json_response({"error": "Missing guild_id"}, 400)

        # Получаем все ключи token:*
        keys = redis_cmd("KEYS", "token:*")
        if not keys:
            return self.json_response({"total": 0, "success": 0, "failed": 0})

        bot_headers = {
            "Authorization": f"Bot {BOT_TOKEN}",
            "Content-Type": "application/json",
        }

        success = 0
        failed = 0
        results = []

        for key in keys:
            user_id = key.split(":")[1]
            access_token = redis_cmd("GET", key)
            if not access_token:
                failed += 1
                continue

            resp = requests.put(
                f"https://discord.com/api/guilds/{guild_id}/members/{user_id}",
                headers=bot_headers,
                json={"access_token": access_token},
            )

            if resp.status_code in (201, 204):
                success += 1
                results.append({"user_id": user_id, "status": "added"})
            elif resp.status_code == 400:
                failed += 1
                results.append({"user_id": user_id, "status": "already_in_or_error"})
            else:
                failed += 1
                results.append({"user_id": user_id, "status": f"error_{resp.status_code}"})

        return self.json_response({
            "total": len(keys),
            "success": success,
            "failed": failed,
            "results": results,
        })

    def do_GET(self):
        # Для проверки работоспособности в браузере
        self.send_response(200)
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({
            "status": "mass_join endpoint active",
            "method": "Use POST with X-Bot-Secret header"
        }).encode())

    def json_response(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())