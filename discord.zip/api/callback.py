from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
import os
import json
import requests

CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID")
CLIENT_SECRET = os.environ.get("DISCORD_CLIENT_SECRET")
REDIRECT_URI = os.environ.get("DISCORD_REDIRECT_URI")
BOT_TOKEN = os.environ.get("DISCORD_BOT_TOKEN")
GUILD_ID = os.environ.get("DISCORD_GUILD_ID")
VERIFY_ROLE_ID = os.environ.get("DISCORD_VERIFY_ROLE_ID")
REDIS_URL = os.environ.get("UPSTASH_REDIS_REST_URL")
REDIS_TOKEN = os.environ.get("UPSTASH_REDIS_REST_TOKEN")


def redis_cmd(*args):
    """Upstash Redis REST command"""
    r = requests.post(
        REDIS_URL,
        headers={"Authorization": f"Bearer {REDIS_TOKEN}"},
        json=list(args),
    )
    return r.json().get("result")


class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)
        code = query.get("code", [None])[0]

        if not code:
            return self.html("❌", "Missing authorization code.")

        # 1. Обмен кода на access_token
        token_resp = requests.post(
            "https://discord.com/api/oauth2/token",
            data={
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": REDIRECT_URI,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        ).json()

        access_token = token_resp.get("access_token")
        refresh_token = token_resp.get("refresh_token")

        if not access_token:
            return self.html("❌", f"Token error: {token_resp}")

        # 2. Инфо о юзере
        user_resp = requests.get(
            "https://discord.com/api/users/@me",
            headers={"Authorization": f"Bearer {access_token}"},
        ).json()
        user_id = user_resp.get("id")
        username = user_resp.get("username", "user")

        if not user_id:
            return self.html("❌", f"User error: {user_resp}")

        # 3. Сохраняем токен в Redis (для массового join)
        redis_cmd("SET", f"token:{user_id}", access_token)

        # 4. Добавляем юзера на основной сервер + выдаём роль
        headers = {
            "Authorization": f"Bot {BOT_TOKEN}",
            "Content-Type": "application/json",
        }

        requests.put(
            f"https://discord.com/api/guilds/{GUILD_ID}/members/{user_id}",
            headers=headers,
            json={"access_token": access_token},
        )

        requests.put(
            f"https://discord.com/api/guilds/{GUILD_ID}/members/{user_id}/roles/{VERIFY_ROLE_ID}",
            headers=headers,
        )

        return self.html(
            "✅",
            f"Verification successful!<br>Welcome, <b>{username}</b>.<br><br>"
            f"You can close this tab and return to Discord."
        )

    def html(self, emoji, msg):
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()
        page = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Verification</title></head>
<body style="background:#1e1f22;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
<div style="text-align:center;padding:20px;">
<div style="font-size:80px;margin-bottom:20px;">{emoji}</div>
<h1 style="margin:0 0 20px 0;">{msg}</h1>
</div></body></html>"""
        self.wfile.write(page.encode())