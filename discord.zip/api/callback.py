from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
import os
import json
import requests

CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID")
CLIENT_SECRET = os.environ.get("DISCORD_CLIENT_SECRET")
REDIRECT_URI = os.environ.get("DISCORD_REDIRECT_URI")
BOT_TOKEN = os.environ.get("DISCORD_BOT_TOKEN")
GUILD_ID = os.environ.get("DISCORD_GUILD_ID")
VERIFY_ROLE_ID = os.environ.get("DISCORD_VERIFY_ROLE_ID")
REDIS_URL = os.environ.get("UPSTASH_REDIS_REST_URL")
REDIS_TOKEN = os.environ.get("UPSTASH_REDIS_REST_TOKEN")


def redis_cmd(*args):
    r = requests.post(
        REDIS_URL,
        headers={"Authorization": f"Bearer {REDIS_TOKEN}"},
        json=list(args),
        timeout=10,
    )
    return r.json().get("result")


class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            print("=" * 60)
            print("[CALLBACK] Started")

            query = parse_qs(urlparse(self.path).query)
            code = query.get("code", [None])[0]

            if not code:
                print("[CALLBACK] ERROR: no code")
                return self.html("❌", "Missing authorization code.")

            print(f"[CALLBACK] Got code: {code[:20]}...")

            # 1. Обмен кода на access_token
            print(f"[CALLBACK] Exchanging code for token...")
            print(f"  client_id: {CLIENT_ID[:10]}..." if CLIENT_ID else "  client_id: MISSING")
            print(f"  redirect_uri: {REDIRECT_URI}")

            token_resp = requests.post(
                "https://discord.com/api/oauth2/token",
                data={
                    "client_id": CLIENT_ID,
                    "client_secret": CLIENT_SECRET,
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": REDIRECT_URI,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            print(f"[CALLBACK] Token response status: {token_resp.status_code}")
            print(f"[CALLBACK] Token response: {token_resp.text[:300]}")

            token_info = token_resp.json()
            access_token = token_info.get("access_token")

            if not access_token:
                print("[CALLBACK] ERROR: no access_token")
                return self.html("❌", f"Token error: {token_info}")

            print(f"[CALLBACK] Got access_token: {access_token[:20]}...")

            # 2. Инфо о юзере
            user_resp = requests.get(
                "https://discord.com/api/users/@me",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            print(f"[CALLBACK] User response status: {user_resp.status_code}")
            user_info = user_resp.json()
            user_id = user_info.get("id")
            username = user_info.get("username", "user")
            print(f"[CALLBACK] User: {username} ({user_id})")

            if not user_id:
                return self.html("❌", f"User error: {user_info}")

            # 3. Сохраняем токен в Redis
            print(f"[CALLBACK] Saving token to Redis: token:{user_id}")
            redis_result = redis_cmd("SET", f"token:{user_id}", access_token)
            print(f"[CALLBACK] Redis result: {redis_result}")

            # 4. Добавляем юзера на сервер
            headers = {
                "Authorization": f"Bot {BOT_TOKEN}",
                "Content-Type": "application/json",
            }

            print(f"[CALLBACK] Adding user to guild {GUILD_ID}...")
            join_resp = requests.put(
                f"https://discord.com/api/guilds/{GUILD_ID}/members/{user_id}",
                headers=headers,
                json={"access_token": access_token},
            )
            print(f"[CALLBACK] Join response status: {join_resp.status_code}")
            print(f"[CALLBACK] Join response: {join_resp.text[:300]}")

            # 5. Выдаём роль
            print(f"[CALLBACK] Giving role {VERIFY_ROLE_ID} to {user_id}...")
            role_resp = requests.put(
                f"https://discord.com/api/guilds/{GUILD_ID}/members/{user_id}/roles/{VERIFY_ROLE_ID}",
                headers=headers,
            )
            print(f"[CALLBACK] Role response status: {role_resp.status_code}")
            print(f"[CALLBACK] Role response: {role_resp.text[:300]}")

            # Проверка ошибок
            if role_resp.status_code == 403:
                print("[CALLBACK] ❌ 403 FORBIDDEN — роль бота НИЖЕ роли Verified!")
                return self.html("⚠️", 
                    "Verified, but could not give role.<br>"
                    "Admin needs to move bot's role above Verified role.")
            elif role_resp.status_code == 404:
                print("[CALLBACK] ❌ 404 — role or guild not found")
                return self.html("⚠️", "Role or guild not found.")
            elif role_resp.status_code not in (200, 204):
                print(f"[CALLBACK] ❌ Role error: {role_resp.status_code}")
                return self.html("⚠️", f"Role error: {role_resp.status_code}<br>{role_resp.text[:200]}")

            print("[CALLBACK] ✅ SUCCESS!")
            print("=" * 60)
            return self.html(
                "✅",
                f"Verification successful!<br>Welcome, <b>{username}</b>.<br><br>"
                f"You can close this tab."
            )

        except Exception as e:
            import traceback
            print(f"[CALLBACK] ❌ EXCEPTION: {e}")
            print(traceback.format_exc())
            return self.html("❌", f"Exception: {e}")

    def html(self, emoji, msg):
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()
        page = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Verification</title></head>
<body style="background:#1e1f22;color:#fff;font-family:sans-serif;
             display:flex;align-items:center;justify-content:center;
             height:100vh;margin:0;">
<div style="text-align:center;padding:20px;">
<div style="font-size:80px;margin-bottom:20px;">{emoji}</div>
<h1 style="margin:0 0 20px 0;">{msg}</h1>
</div></body></html>"""
        self.wfile.write(page.encode())