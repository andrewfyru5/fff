from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
import os
import requests
import json

# --- НАСТРОЙКИ (Будут взяты из переменных окружения Vercel) ---
CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID")
CLIENT_SECRET = os.environ.get("DISCORD_CLIENT_SECRET")
REDIRECT_URI = os.environ.get("DISCORD_REDIRECT_URI")
BOT_TOKEN = os.environ.get("DISCORD_BOT_TOKEN")
# --- КОНЕЦ НАСТРОЕК ---

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)
        code = query.get("code", [None])[0]

        if not code:
            self.send_response(400)
            self.send_header("Content-type", "text/plain")
            self.end_headers()
            self.wfile.write(b"Error: Missing authorization code.")
            return

        # 1. Меняем код на access_token
        data = {
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": REDIRECT_URI,
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = requests.post("https://discord.com/api/oauth2/token", data=data, headers=headers)
        token_info = response.json()
        access_token = token_info.get("access_token")

        if not access_token:
            self.send_response(400)
            self.send_header("Content-type", "text/plain")
            self.end_headers()
            self.wfile.write(b"Error: Could not get access token.")
            return

        # 2. Получаем информацию о пользователе
        user_headers = {"Authorization": f"Bearer {access_token}"}
        user_response = requests.get("https://discord.com/api/users/@me", headers=user_headers)
        user_info = user_response.json()
        user_id = user_info.get("id")

        # 3. Отправляем команду боту выдать роль
        # (Используем вебхук или отдельный API-эндпоинт, но для простоты отправим запрос на "фейковый" порт бота)
        # Для реальной работы бот и сайт должны общаться через базу данных или Redis.
        # В данном примере мы просто покажем успех.
        
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        success_html = f"""
        <html>
        <body style="background-color: #2f3136; color: white; font-family: sans-serif; text-align: center; padding-top: 50px;">
            <h1>✅ Verification Successful!</h1>
            <p>You have been verified as <strong>{user_info.get('username')}</strong>.</p>
            <p>You can now close this tab and return to Discord.</p>
            <p>Your Discord ID: {user_id}</p>
        </body>
        </html>
        """
        self.wfile.write(success_html.encode())
        return

    def do_POST(self):
        self.send_response(405)
        self.end_headers()